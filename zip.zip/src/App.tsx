import React from 'react';

import { Container } from './styles'

import Header from './components/Header';
import InputComponent from './components/InputComponent';
import Feed from './components/Feed';

function App() {
  return (
    <Container>
      <Header/>
      <InputComponent inputValue='' textAreaValue='' />
      <Feed/>
    </Container>
  );
}

export default App;
