import React from 'react'
import { Container, TitleContainer, TitleUp, TitleDown } from './styles'


function Header() {
  return (
    <Container>
      <TitleContainer>
        <TitleUp>
          buildbox
        </TitleUp>
        <TitleDown>
          WEB CHALLENGE
        </TitleDown>
      </TitleContainer>

    </Container>
  )
}

export default Header