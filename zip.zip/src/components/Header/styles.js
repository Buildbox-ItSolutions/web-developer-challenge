import styled from "styled-components";

const Container = styled.div`
  width: 100vw;
  height: 10vh;
  background: #28282B;

  justify-content: center;
  align-content: center;
`;

const TitleContainer = styled.div`
  display:block;
  margin-left: 47%;

  padding-top: 1%;
`;

const TitleUp = styled.h1`
  
  font-weight: 900;
  font-size: 24pt;
  
  margin:0;
  padding: 0;
  color: rgb(124, 184, 0);
`;

const TitleDown = styled.h1`
  
  font-weight: 200;
  font-size: 14pt;

  margin:0;
  padding: 0;
  color: #808080;
`;

export {
  Container,
  TitleContainer,
  TitleUp,
  TitleDown,
}