import React, { useState} from 'react'

import { Container,
  PhotoContainer, PhotoDefault, Photo, PhotoContainerDefault,
  SmallInput, BigInput, 
  ButtonContainer, PublishButton, DisabledButton,
  MiniButton, DisabledMiniButton } from './styles'
import imageDefaultIcon from '../../assets/images/imageDefaultIcon.png'

interface Props {
  image?: any;
  inputValue: string,
  textAreaValue: string,
}

function InputComponent(props: Props) {

  const [buttonState, setButtonState] = React.useState(false)


  return (
    <Container>

        {props.image ? 
          <PhotoContainer>
            <Photo src={props.image} alt={'image profile'} />
          </PhotoContainer>
          :
          <PhotoContainerDefault>
            <PhotoDefault src={imageDefaultIcon} alt={'image profile'} />
          </PhotoContainerDefault>
        }
      

      <SmallInput placeholder={'Digite seu nome'} />
      <BigInput placeholder={'Mensagem'} />

      <ButtonContainer>

        {buttonState ?
          <MiniButton>
            Descartar
          </MiniButton>
          :
          <DisabledMiniButton>
            Descartar
          </DisabledMiniButton>
        }

        {buttonState ?
          <PublishButton>
            Publicar
          </PublishButton>
          :
          <DisabledButton>
            Publicar
          </DisabledButton>
        }
      </ButtonContainer>
    </Container>
  )
}

export default InputComponent