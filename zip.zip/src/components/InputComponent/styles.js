import styled from "styled-components";

const Container = styled.div`
  width: 30vw;
  height: 40vh;
  background: #313131;

  padding: 50px;

  border-style: solid;
  border-width: 0.5px;
  border-color: #4a4949;
  border-radius: 3px;

  box-shadow: 2px 2px 2px #313131;

  margin: auto;
  margin-top: 3%;

  justify-content: center;
  align-content: center;
`;

const Photo = styled.img`
  width: 120px;
  height: 120px;
  border-radius: 40px;
`;

const PhotoContainer = styled.div`
  width: 50%;
  height: 33%;
  margin-left: 28%;
  display:flex;

  justify-content: center;
`;

const PhotoDefault = styled.img`
  width: 40px;
  height: 40px;
`;

const PhotoContainerDefault = styled.div`
  width: 120px;
  height: 120px;
  margin-left: 40%;

  border-style: solid;
  border-width: 0.5px;
  border-color: #4a4949;
  border-radius: 50px;

  display:flex;

  justify-content: center;
  align-items: center;
`;

const SmallInput = styled.input`
  width: 95%;
  padding: 1rem;
  font-size: 14pt;
  margin: 10px;
  color: #FFF;
  ::placeholder{
    color: #808080;
  }

  background: #4a4949;

  border-radius: 10px;
  border-style: none;
`;

const BigInput = styled.textarea`
  width: 95%;
  height: 20%;
  padding: 1rem;
  font-size: 14pt;
  margin: 10px;
  color: #FFF;
  ::placeholder{
    color: #808080;
  }
  :focus{
    border-style: none;
  }

  background: #4a4949;

  border-radius: 10px;
  border-style: none;

`;

const ButtonContainer = styled.div`
  width: 100%;
  display: inline-block;
  margin-left: 47%;
`;

const PublishButton = styled.button`
  width: 25%;
  height: 15%;
  padding: 1rem;
  font-size: 14pt;
  margin: 10px;
  color: #FFF;
  ::placeholder{
    color: #808080;
  }
  :focus{
    border-style: none;
  }

  background: #71bb00;

  border-radius: 10px;
  border-style: none;

`;

const MiniButton = styled.button`
  width: 25%;
  height: 15%;
  padding: 1rem;
  font-size: 14pt;
  margin: 10px;
  color: #4a4949;
  text-decoration: underline;
  :hover{
    cursor: pointer;
  }

  background: transparent;

  border-radius: 10px;
  border-style: none;

`;
const DisabledMiniButton = styled.button`
  width: 25%;
  height: 15%;
  padding: 1rem;
  font-size: 14pt;
  margin: 10px;
  color: #4a4949;
  text-decoration: underline;
  :hover{
    cursor: default;
  }

  background: transparent;

  border-radius: 10px;
  border-style: none;

`;


const DisabledButton = styled.button`
  width: 25%;
  height: 15%;
  padding: 1rem;
  font-size: 14pt;
  font-weight: 500;
  margin: 10px;
  color: #313131;
  ::placeholder{
    color: #808080;
  }
  :focus{
    border-style: none;
  }

  background: #4a4949;

  border-radius: 10px;
  border-style: none;

`;

export {
  Container,
  PhotoContainer,
  PhotoDefault,
  PhotoContainerDefault,
  Photo,
  SmallInput,
  BigInput,
  ButtonContainer,
  PublishButton,
  MiniButton,
  DisabledButton,
  DisabledMiniButton,
}