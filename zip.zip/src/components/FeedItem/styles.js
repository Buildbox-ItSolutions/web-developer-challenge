import styled from 'styled-components';

const Container = styled.div`
  width: 30vw;
  height: 20vh;
  background: #313131;

  padding: 50px;

  border-style: solid;
  border-width: 0.5px;
  border-color: #4a4949;
  border-radius: 3px;

  box-shadow: 2px 2px 2px #313131;

  margin: auto;
  margin-top: 3%;

  display: grid;
  grid-template-columns: 30% 70%;

`;

const Photo = styled.img`
  width: 120px;
  height: 120px;
  border-radius: 40px;
`;

const RightContainer = styled.div`
  width: 100% ;
  height: 100%;

  margin:0;

  margin-left:100% ;

  display: grid;
  grid-template-rows: 50% 50%;
`;

const Text = styled.p`
  width: 90%;
  color:#808080;
  font-size:14pt;
`;

const SendBy = styled.p`
  margin:0;
  color:#4a4949;
  font-weight: 700 ;
  font-size:10pt;
`;

const TextBy = styled.p`
  margin:0;
  color:#808080;
  font-size:12pt;
`;

export {
  Container,
  Photo,
  RightContainer,
  Text,
  SendBy,
  TextBy,
}
