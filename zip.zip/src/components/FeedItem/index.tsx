import React from 'react'
import {
  Container,
  Photo,
  RightContainer,
  Text,
  SendBy,
  TextBy
} from './styles'

interface Props {
  id:number,
  image: any,
  text: string,
  sendBy: string
}

function FeedItem(props: Props) {
  return (
    <Container>

      <Photo src={props.image}/>
      
      <>
        <Text>
          {props.text}
        </Text>

      <RightContainer>
        <SendBy>
          Enviado por:
        </SendBy>
        <TextBy>
          {props.sendBy}
        </TextBy>
      </RightContainer>
      </>

    </Container>
  )
}

export default FeedItem