import React, { useState } from 'react'

import { Container, TitleFeed} from './styles'
import { data as Gift } from './data'

import FeedItem from '../FeedItem'

function Feed() {

  const [data, setData ] = React.useState(Gift)

  const text = `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s`
  return (
    <Container>
      <TitleFeed>
        Feed
      </TitleFeed>

      {data.map((item)=>{
        return(
          <FeedItem id={item.id} image={item.image} text={item.text} sendBy={item.sendBy}/>
        )
      })}
    </Container>
  )
}

export default Feed