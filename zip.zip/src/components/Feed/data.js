import Image from '../../assets/images/chika1.jpg'

export const data = [
  {
    id:1,
    image: Image,
    text: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s`,
    sendBy: 'Caio Stato',
  },
  {
    id:2,
    image: Image,
    text: `Lorem Ipsum is simply dummy text of the printing and typesetting industry.`,
    sendBy: 'User 1',
  },
  {
    id:3,
    image: Image,
    text: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s`,
    sendBy: 'User 2',
  },
]