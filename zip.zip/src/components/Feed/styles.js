import styled from 'styled-components';

const Container = styled.div`
  width: 35vw;
  margin: auto;
  margin-top: 3%;

  display:flex;
  flex-direction: column;
`;
const TitleFeed = styled.h2`

  color: #808080;
  margin:0;

  font-weight: 500;
  font-size:14pt ;
`;
export { 
  Container,
  TitleFeed,
}
